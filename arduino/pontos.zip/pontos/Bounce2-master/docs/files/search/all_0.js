var searchData=
[
  ['attach',['attach',['../class_bounce.html#aba08e592941465d033e3eba3dde66eaf',1,'Bounce::attach(int pin, int mode)'],['../class_bounce.html#a163477dbcbaf1a3dee6cb3b62eedf09e',1,'Bounce::attach(int pin)']]]
];
